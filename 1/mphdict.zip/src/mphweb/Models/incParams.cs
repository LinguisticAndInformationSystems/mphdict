﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mphweb.Models
{
    public class incParams
    {
        public int wid { get; set; }
        public int currentPage { get; set; }
        public string wordSearch { get; set; }
    }
}
