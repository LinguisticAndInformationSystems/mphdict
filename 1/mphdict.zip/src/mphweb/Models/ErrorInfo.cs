﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mphweb.Models
{
    public class ErrorInfo
    {
        public int id { get; set; }
        public string verbalInfo { get; set; }
    }
}
